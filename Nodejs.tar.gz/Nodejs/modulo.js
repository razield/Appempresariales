function suma(x, y){
	var sum = x + y;
	return sum;
}
exports.suma = suma;